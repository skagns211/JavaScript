import "./actions/__test__/index.test";
import "./reducers/__test__/index.test";
import "./pages/__test__/index.test";